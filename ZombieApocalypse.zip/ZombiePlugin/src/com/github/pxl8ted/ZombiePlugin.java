package com.github.pxl8ted;

import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class ZombiePlugin extends JavaPlugin {
	//Defines listener
	public final MainListener pluginListener = new MainListener();
	//Controls the disable method
	public void onDisable() { }
	//Controls the enable method
	public void onEnable() {
		PluginManager pm = getServer().getPluginManager();
		//Handles events
		pm.registerEvents(pluginListener, this);
		
	}

}
